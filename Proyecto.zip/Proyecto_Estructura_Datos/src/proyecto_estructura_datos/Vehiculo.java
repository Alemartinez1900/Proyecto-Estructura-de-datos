/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_estructura_datos;

import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
public class Vehiculo {

    private String color;
    private int anno;
    private int cilindraje;
    private String marca;
    private String modelo;
    private int kilometraje;
    private String tipo;
    private String caracteristicas;
    private String estado;
    private Cliente cliente;
    private Usuario vendedor;
    private boolean vendido = false;

    public Vehiculo(String color, int anno, int cilindraje, String marca, String modelo, int kilometraje, String tipo, String caracteristicas, String estado, Cliente cliente, Usuario vendedor) {
        this.color = color;
        this.anno = anno;
        this.cilindraje = cilindraje;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometraje = kilometraje;
        this.tipo = tipo;
        this.caracteristicas = caracteristicas;
        this.estado = estado;
        this.cliente = cliente;
        this.vendedor = vendedor;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getAnno() {
        return anno;
    }

    public void setAnno(int anno) {
        this.anno = anno;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(int kilometraje) {
        this.kilometraje = kilometraje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        if (!vendido) {
            this.estado = estado;
        }
    }

    public Usuario getVendedor() {
        return vendedor;
    }

    public void setVendedor(Usuario vendedor) {
        this.vendedor = vendedor;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public boolean isVendido() {
        return vendido;
    }

    public void setVendido(boolean vendido) {
        this.vendido = vendido;
    }

    public static Vehiculo crearVehiculo() {
        String color = JOptionPane.showInputDialog("Ingrese el color del vehículo: ");
        int anno = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año del vehículo: "));
        int cilindraje = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el cilindraje del vehículo: "));
        String marca = JOptionPane.showInputDialog("Ingrese la marca del vehículo: ");
        String modelo = JOptionPane.showInputDialog("Ingrese el modelo del vehículo: ");
        int kilometraje = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el kilometraje del vehículo: "));
        String tipo = JOptionPane.showInputDialog("Ingrese el tipo del vehículo: ");
        String caracteristicas = JOptionPane.showInputDialog("Ingrese las características del vehículo: ");
        String estado = JOptionPane.showInputDialog("Ingrese el estado del vehículo: ");

        Cliente cliente = null;
        Usuario vendedor = null;

        Vehiculo vehiculo = new Vehiculo(color, anno, cilindraje, marca, modelo, kilometraje, tipo, caracteristicas, estado, cliente, vendedor);

        return vehiculo;
    }

    public void reservar(Cliente cliente) {
        if (cliente != null && this.cliente == null) {
            this.cliente = cliente;
            this.estado = "Reservado";
        }
    }

    public void vender(Cliente cliente) {
        if (cliente != null && this.cliente == null) {
            this.cliente = cliente;
            this.estado = "Comprado";
        }
    }

    public void cancelarVenta() {
        if (vendido) {
            this.estado = "Disponible";
            this.cliente = null;
            vendido = false;
        }
    }

    public void marcarComoVendido() {
        vendido = true;
    }

    public void subMenuVehiculo() {
        boolean salir = false;
        while (!salir) {
            String opcion = JOptionPane.showInputDialog(
                    "Submenú de Vehículos:\n"
                    + "1. Crear un nuevo vehículo\n"
                    + "2. Reservar un vehículo\n"
                    + "3. Vender un vehículo\n"
                    + "4. Cancelar venta de un vehículo\n"
                    + "5. Salir del submenú"
            );

            switch (opcion) {
                case "1":
                    crearVehiculo();

                    break;
                case "2":

                    break;
                case "3":
                    // Lógica para vender un vehículo
                    break;
                case "4":
                    // Lógica para cancelar la venta de un vehículo
                    break;
                case "5":
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, elige una opción válida.");
            }
        }
    }

}
