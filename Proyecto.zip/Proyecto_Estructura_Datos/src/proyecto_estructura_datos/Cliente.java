/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_estructura_datos;

import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
public class Cliente {

    private String nombre;
    private String apellidos;
    private String identificacion;
    private String correoElectronico;
    private String telefono;

    public Cliente(String nombre, String apellidos, String identificacion, String correoElectronico, String telefono) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.identificacion = identificacion;
        this.correoElectronico = correoElectronico;
        this.telefono = telefono;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Cliente crearCliente() {

        Cliente clienteNuevo = new Cliente(nombre, apellidos, identificacion, correoElectronico, telefono);
        this.nombre = (JOptionPane.showInputDialog("ingrese el nombre del cliente: "));
        this.apellidos = (JOptionPane.showInputDialog("Ingrese los apellidos del cliente: "));
        this.identificacion = JOptionPane.showInputDialog("Ingrese la didentificación del cliente: ");
        this.correoElectronico = JOptionPane.showInputDialog("Ingrese el correo electrónico del cliente: ");
        this.telefono = (JOptionPane.showInputDialog("Ingrese el número de teléfono del cliente: "));
        JOptionPane.showMessageDialog(null,"Cliente creado con éxito");
        return clienteNuevo;
    }

    public void menuCliente() {
        boolean salir = false;

        while (!salir) {
            int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                "Menú de Cliente:\n" +
                "1. Crear nuevo Cliente\n" +
                "2. Editar Correo Electrónico\n" +
                "3. Editar Teléfono\n" +
                "4. Volver al Menú Principal"
            ));

            switch (opcion) {
                case 1:
                    crearCliente();
                    break;


                case 2:
                    String nuevoCorreo = JOptionPane.showInputDialog("Ingrese el nuevo correo electrónico: ");
                    setCorreoElectronico(nuevoCorreo);
                    break;
                case 3:
                    String nuevoTelefono = JOptionPane.showInputDialog("Ingrese el nuevo teléfono: ");
                    setTelefono(nuevoTelefono);
                    break;
                case 4:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }
}
