/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_estructura_datos;

import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
public class Usuario {

    private String nombreUsuario;
    private String apellidoUsuario;
    private String identificacion;
    private String correoElectronico;
    private int telefono;
    private String contrasena;
    private String tipoUsuario;

    public Usuario(String nombreUsuario, String apellidoUsuario, String identificacion, String correoElectronico, int telefono, String contrasena, String tipoUsuario) {
        this.nombreUsuario = nombreUsuario;
        this.apellidoUsuario = apellidoUsuario;
        this.identificacion = identificacion;
        this.correoElectronico = correoElectronico;
        this.telefono = telefono;
        this.contrasena = contrasena;
        this.tipoUsuario = tipoUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return apellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public static Usuario crearUsuario() {

        String nombreUsuario = JOptionPane.showInputDialog("Ingrese el nombre del usuario: ");
        String apellidoUsuario = JOptionPane.showInputDialog("Ingrese el apellido del usuario: ");
        String identificacion = JOptionPane.showInputDialog("Ingrese la identificación del usuario: ");
        String correoElectronico = JOptionPane.showInputDialog("Ingrese el correo electrónico del usuario: ");
        int telefono = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de teléfono del usuario: "));
        String contrasena = JOptionPane.showInputDialog("Ingrese la contraseña del usuario: ");
        String tipoUsuario = JOptionPane.showInputDialog("Ingrese el tipo de usuario: ");

        Usuario nuevoUsuario = new Usuario(nombreUsuario, apellidoUsuario, identificacion, correoElectronico, telefono, contrasena, tipoUsuario);

        return nuevoUsuario;
    }
    
        public void submenuUsuarios() {
        boolean salir = false;
        while (!salir) {
            String opcion = JOptionPane.showInputDialog(
                "Submenú de Usuarios:\n" +
                "1. Crear un nuevo usuario\n" +
                "2. Mostrar información de un usuario\n" +
                "3. Editar información de un usuario\n" +
                "4. Eliminar un usuario\n" +
                "5. Volver"
            );

            switch (opcion) {
                case "1":
                    // Crear un nuevo usuario
                    Usuario nuevoUsuario = crearUsuario();
                    
                    break;
                case "2":
                    // Lógica para mostrar información de un usuario
                    break;
                case "3":
                    // Lógica para editar información de un usuario
                    break;
                case "4":
                    // Lógica para eliminar un usuario
                    break;
                case "5":
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, elige una opción válida.");
                    break;
            }
        }
    }
}
