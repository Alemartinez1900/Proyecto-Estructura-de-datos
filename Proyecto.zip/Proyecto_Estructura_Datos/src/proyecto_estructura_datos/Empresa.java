/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_estructura_datos;

/**
 *
 * @author LENOVO
 */
public class Empresa {
    
    static String nombreEmpresa = "AzzaCar";
    static String telefono = "8888 8888";
    static String direccion = "Cartago, Cartago, Occidental.";

    public static String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public static String getTelefono() {
        return telefono;
    }

    public static String getDireccion() {
        return direccion;
    }
    
    
    
}
