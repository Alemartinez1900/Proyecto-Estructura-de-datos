/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_estructura_datos;

import javax.swing.JOptionPane;

/**
 *
 * @author LENOVO
 */
public class Menu {
Usuario menuUsuario = new Usuario("opcionTexto", " opcionTexto", "opcionTexto", "opcionTexto", 0, "opcionTexto", " opcionTexto");

Cliente menuCli = new Cliente("opcionTexto", "opcionTexto", " opcionTexto", "opcionTexto", " opcionTexto");

Vehiculo menuVehiculo = new Vehiculo("color", 0, 0, "marca", "modelo", 0, "tipo", "caracteristicas", "estado", menuCli, menuUsuario);

public void mostrarMenu() {

        String opcionTexto = JOptionPane.showInputDialog("Por favor elija una opcion: \n"
                + "1- Usuarios \n"
                + "2- Vehículos \n"
                + "3- Clientes \n"
                + "4- Garantías \n"
                + "5- Reportes \n"
                + "0- Salir");

        int opcion = Integer.parseInt(opcionTexto);

        switch (opcion) {
            case 1:
                
                menuUsuario.submenuUsuarios();
                mostrarMenu();
                break;
            case 2:
                
                menuVehiculo.subMenuVehiculo();
                mostrarMenu();
                break;

            case 3:
                
                menuCli.menuCliente();
                mostrarMenu();
                break;

            default:
                JOptionPane.showMessageDialog(null, "Opción no válida");
                mostrarMenu();
        }

    }

}
